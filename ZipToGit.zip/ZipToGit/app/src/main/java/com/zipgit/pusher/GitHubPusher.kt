package com.zipgit.pusher

import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ZipFileItem(val path: String, val bytes: ByteArray)

class GitHubPusher(private val token: String) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(180, TimeUnit.SECONDS)
        .build()
    private val json = "application/json; charset=utf-8".toMediaType()

    private fun call(method: String, path: String, body: JSONObject? = null): Pair<Int, String> {
        val rb = when {
            body != null -> body.toString().toRequestBody(json)
            method == "GET" -> null
            else -> "".toRequestBody(json)
        }
        val req = Request.Builder()
            .url("https://api.github.com$path")
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json")
            .header("X-GitHub-Api-Version", "2022-11-28")
            .method(method, rb)
            .build()
        client.newCall(req).execute().use { return it.code to (it.body?.string() ?: "") }
    }

    private fun ok(r: Pair<Int, String>, what: String): JSONObject {
        if (r.first !in 200..299) {
            val msg = try { JSONObject(r.second).optString("message") } catch (e: Exception) { r.second.take(200) }
            throw RuntimeException("$what failed (${r.first}): $msg")
        }
        return JSONObject(r.second)
    }

    fun push(
        owner: String, repo: String, branch: String, folder: String, message: String,
        files: List<ZipFileItem>, createIfMissing: Boolean, log: (String) -> Unit
    ) {
        val base = "/repos/$owner/$repo"
        log("Repo check kar raha hu...")
        var info = call("GET", base)
        if (info.first == 404 && createIfMissing) {
            log("Repo nahi mila, naya private repo bana raha hu...")
            ok(call("POST", "/user/repos", JSONObject().put("name", repo).put("private", true).put("auto_init", true)), "Repo create")
            Thread.sleep(2000)
            info = call("GET", base)
        }
        val repoJson = ok(info, "Repo")
        val defBranch = repoJson.optString("default_branch", "main")

        var refSha: String? = null
        val ref = call("GET", "$base/git/ref/heads/$branch")
        if (ref.first == 200) {
            refSha = JSONObject(ref.second).getJSONObject("object").getString("sha")
        } else {
            var defRef = call("GET", "$base/git/ref/heads/$defBranch")
            if (defRef.first != 200) {
                log("Repo khali hai, initialize kar raha hu...")
                val init = JSONObject()
                    .put("message", "Initial commit")
                    .put("content", Base64.encodeToString("init".toByteArray(), Base64.NO_WRAP))
                    .put("branch", defBranch)
                ok(call("PUT", "$base/contents/.gitkeep-init", init), "Init")
                defRef = call("GET", "$base/git/ref/heads/$defBranch")
            }
            val defSha = ok(defRef, "Default branch").getJSONObject("object").getString("sha")
            if (branch != defBranch) {
                log("Branch '$branch' bana raha hu...")
                ok(call("POST", "$base/git/refs", JSONObject().put("ref", "refs/heads/$branch").put("sha", defSha)), "Branch create")
            }
            refSha = defSha
        }

        val treeSha = ok(call("GET", "$base/git/commits/$refSha"), "Commit").getJSONObject("tree").getString("sha")

        val prefix = folder.trim().trim('/').let { if (it.isEmpty()) "" else "$it/" }
        val entries = JSONArray()
        files.forEachIndexed { i, f ->
            log("Upload ${i + 1}/${files.size}: ${f.path}")
            val blob = ok(
                call("POST", "$base/git/blobs", JSONObject()
                    .put("content", Base64.encodeToString(f.bytes, Base64.NO_WRAP))
                    .put("encoding", "base64")),
                "Blob ${f.path}"
            )
            entries.put(JSONObject().put("path", prefix + f.path).put("mode", "100644").put("type", "blob").put("sha", blob.getString("sha")))
        }

        log("Tree bana raha hu...")
        val newTree = ok(call("POST", "$base/git/trees", JSONObject().put("base_tree", treeSha).put("tree", entries)), "Tree").getString("sha")
        log("Commit bana raha hu...")
        val commit = ok(
            call("POST", "$base/git/commits", JSONObject()
                .put("message", message).put("tree", newTree).put("parents", JSONArray().put(refSha))),
            "Commit"
        ).getString("sha")
        ok(call("PATCH", "$base/git/refs/heads/$branch", JSONObject().put("sha", commit)), "Ref update")
        log("DONE ✅ ${files.size} files push ho gayi: https://github.com/$owner/$repo/tree/$branch")
    }
}
