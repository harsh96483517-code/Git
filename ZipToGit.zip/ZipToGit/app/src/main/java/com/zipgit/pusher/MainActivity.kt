package com.zipgit.pusher

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.zip.ZipInputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { Screen() } } }
    }

    private fun nameOf(uri: Uri): String =
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && i >= 0) c.getString(i) else null
        } ?: "file.zip"

    private fun readZip(uri: Uri, strip: Boolean): List<ZipFileItem> {
        val out = ArrayList<ZipFileItem>()
        contentResolver.openInputStream(uri)!!.use { ins ->
            ZipInputStream(ins.buffered()).use { zin ->
                var e = zin.nextEntry
                while (e != null) {
                    val p = e.name.replace('\\', '/').trimStart('/')
                    val skip = e.isDirectory || p.startsWith("__MACOSX/") || p.endsWith(".DS_Store") ||
                        p.split('/').any { it == ".." }
                    if (!skip) out.add(ZipFileItem(p, zin.readBytes()))
                    zin.closeEntry()
                    e = zin.nextEntry
                }
            }
        }
        if (strip && out.isNotEmpty()) {
            val first = out[0].path.substringBefore('/', "")
            if (first.isNotEmpty() && out.all { it.path.startsWith("$first/") }) {
                return out.map { ZipFileItem(it.path.removePrefix("$first/"), it.bytes) }
            }
        }
        return out
    }

    @Composable
    fun Screen() {
        val prefs = remember { getSharedPreferences("zipgit", MODE_PRIVATE) }
        val scope = rememberCoroutineScope()
        var token by remember { mutableStateOf(prefs.getString("token", "") ?: "") }
        var owner by remember { mutableStateOf(prefs.getString("owner", "") ?: "") }
        var repo by remember { mutableStateOf(prefs.getString("repo", "") ?: "") }
        var branch by remember { mutableStateOf(prefs.getString("branch", "main") ?: "main") }
        var folder by remember { mutableStateOf("") }
        var message by remember { mutableStateOf("Upload from zip") }
        var strip by remember { mutableStateOf(true) }
        var create by remember { mutableStateOf(true) }
        var zipUri by remember { mutableStateOf<Uri?>(null) }
        var zipName by remember { mutableStateOf("") }
        var files by remember { mutableStateOf<List<ZipFileItem>>(emptyList()) }
        var busy by remember { mutableStateOf(false) }
        val logs = remember { mutableStateListOf<String>() }

        fun load(uri: Uri) {
            scope.launch {
                try {
                    files = withContext(Dispatchers.IO) { readZip(uri, strip) }
                    logs.add("Zip padh li: ${files.size} files")
                } catch (e: Exception) { logs.add("Zip error: ${e.message}") }
            }
        }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) { zipUri = uri; zipName = nameOf(uri); load(uri) }
        }

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Zip → GitHub", style = MaterialTheme.typography.headlineMedium)
            OutlinedTextField(token, { token = it }, label = { Text("GitHub token (repo access)") },
                visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(owner, { owner = it }, label = { Text("Username / Owner") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(repo, { repo = it }, label = { Text("Repo name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(branch, { branch = it }, label = { Text("Branch") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(folder, { folder = it }, label = { Text("Repo ke andar folder (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(message, { message = it }, label = { Text("Commit message") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(strip, { strip = it; zipUri?.let { u -> load(u) } })
                Text("Zip ka upar wala root folder hatao")
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(create, { create = it })
                Text("Repo na ho to private repo bana do")
            }
            OutlinedButton({ picker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) },
                Modifier.fillMaxWidth()) { Text(if (zipName.isEmpty()) "Zip file chuno" else "$zipName (${files.size} files)") }
            Button(
                onClick = {
                    prefs.edit().putString("token", token).putString("owner", owner)
                        .putString("repo", repo).putString("branch", branch).apply()
                    busy = true
                    scope.launch {
                        try {
                            withContext(Dispatchers.IO) {
                                GitHubPusher(token.trim()).push(owner.trim(), repo.trim(), branch.trim(), folder, message, files, create) { m ->
                                    scope.launch { logs.add(m) }
                                }
                            }
                        } catch (e: Exception) { logs.add("ERROR: ${e.message}") }
                        busy = false
                    }
                },
                enabled = !busy && files.isNotEmpty() && token.isNotBlank() && owner.isNotBlank() && repo.isNotBlank() && branch.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (busy) "Push ho raha hai..." else "GitHub pe Push karo") }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            logs.takeLast(40).forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}
