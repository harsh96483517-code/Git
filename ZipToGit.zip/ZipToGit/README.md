# Zip to GitHub
Zip chuno -> sari files ek hi commit me tumhare GitHub repo me push.
Token: GitHub > Settings > Developer settings > Personal access tokens > Fine-grained (Contents: Read & Write) ya classic (repo scope).
Build: ye project GitHub pe push karo, Actions > Build APK > artifact download.
